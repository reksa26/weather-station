<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "stasiuncuaca";

    $koneksi = mysqli_connect($server, $username, $password,$database);

?>