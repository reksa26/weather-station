<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Stasiun Cuaca.xls");
?>

<!doctype html>
<html lang="id">
<head>
</head>
<body class="bg-light">
    <br>
    <div class="container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Waktu</th>
                    <th scope="col">Suhu</th>
                    <th scope="col">Kelembaban</th>
                    <th scope="col">Kondisi Cuaca</th>
                </tr>
            </thead>
            <?php
            include('koneksi.php');
            header('refresh: 5');
            $query  = "SELECT * FROM data ORDER BY no ASC";
            $data   = mysqli_query($koneksi, $query);
            while ($row = mysqli_fetch_array($data)) {
            ?>
                <tbody>
                    <tr>
                        <td><?php echo $row['No']; ?></td>
                        <td><?php echo $row['tanggal']; ?></td>
                        <td><?php echo $row['waktu']; ?></td>
                        <td><?php echo $row['suhu']; ?></td>
                        <td><?php echo $row['kelembaban']; ?></td>
                        <td><?php echo $row['kondisicuaca']; ?></td>
                    </tr>
                </tbody>
            <?php } ?>
        </table>
    </div>
</body>

</html>