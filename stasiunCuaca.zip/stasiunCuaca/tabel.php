<!doctype html>
<html lang="id">

<head>
    <?php include('desain.php'); ?>
</head>

<body class="bg-light">
    <?php include('navbar.php'); ?>
    <br>
    <div class="container">
        <a href="export.php" class="btn btn-success">EXPORT EXCEL </a>
        <br><br>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Waktu</th>
                    <th scope="col">Suhu</th>
                    <th scope="col">Kelembaban</th>
                    <th scope="col">Kondisi Cuaca</th>
                </tr>
            </thead>
            <?php
            include('koneksi.php');
            header('refresh: 5');
            $query  = "SELECT * FROM data ORDER BY no DESC LIMIT 20";
            $data   = mysqli_query($koneksi, $query);
            while ($row = mysqli_fetch_array($data)) {
            ?>
                <tbody>
                    <tr>
                        <td><?php echo $row['No']; ?></td>
                        <td><?php echo $row['tanggal']; ?></td>
                        <td><?php echo $row['waktu']; ?></td>
                        <td><?php echo $row['suhu']; ?></td>
                        <td><?php echo $row['kelembaban']; ?></td>
                        <td><?php echo $row['kondisicuaca']; ?></td>
                    </tr>
                </tbody>
            <?php } ?>
        </table>
    </div>
</body>

</html>