<?php
    include('koneksi.php');
    $suhu = @$_GET['suhu'];
    $kelembaban = @$_GET['kelemababan'];
    $kondisicuaca = @$_GET['kondisicuaca'];

    $tanggal = date('d-m-Y');
    $waktu = date('H:i:s');

    $query = "INSERT INTO data(tanggal, waktu, suhu, kelembaban, kondisicuaca) VALUES ('$tanggal','$waktu','$suhu','$kelembaban','$kondisicuaca')";
    $input = mysqli_query($koneksi, $query);

    if($input == TRUE){
        echo " berhasil su";
        }else{
            echo "gagal su";
    }