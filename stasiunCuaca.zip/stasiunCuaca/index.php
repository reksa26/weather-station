<?php
include('koneksi.php');

#header('refresh: 5');

$query  = "SELECT * FROM data ORDER BY no DESC LIMIT 1";
$data   = mysqli_query($koneksi, $query);
$row    = mysqli_fetch_array($data);

$suhu           = $row['suhu'];
$kelembaban     = $row['kelembaban'];
$kondisicuaca   = $row['kondisicuaca'];

?>
<!doctype html>
<html lang="id">

<head>
    <?php include('desain.php'); ?>
</head>

<body class="bg-light">
    <?php include('navbar.php'); ?>
    <br>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-white">
                        <b>Suhu</b>
                    </div>
                    <dic class="card-body">
                        <h3><?php echo $suhu; ?></h3>
                    </dic>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-header bg-white">
                        <b>Kelembaban</b>
                    </div>
                    <dic class="card-body">
                        <h3><?php echo $kelembaban; ?></h3>
                    </dic>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-header bg-white">
                        <b>Kondisi Cuaca</b>
                    </div>
                    <dic class="card-body bg-white">
                        <h3><?php echo $kondisicuaca; ?></h3>
                    </dic>
                </div>
            </div>
        </div>
    </div>
</body>

</html>